import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class task2 {
    private static Path USERS_LIST = Paths.get("users.list");
    private static Path TASKS_LIST = Paths.get("tasks.list");

    private static void createUser(String[] args) throws Exception {
        String firstName = null;
        String lastName = null;
        String UserName = null;

        for (String arg : args) {
            if (arg.startsWith("-fn=")) {
                firstName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-ln=")) {
                lastName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            }
        }

        if (Files.exists(USERS_LIST)) {
            List<String> userLines = Files.readAllLines(USERS_LIST);
            for (String userLine : userLines) {
                String[] userData = userLine.split(",");

                if (userData[2].equals(UserName)) {
                    throw new RuntimeException("User already exists");
                }
            }
        }

        String userLine = String.format("%s,%s,%s\n", firstName, lastName, UserName);
        Files.writeString(USERS_LIST, userLine, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private static void showAllUsers(String[] args) throws Exception {
        if (Files.exists(USERS_LIST)) {
            List<String> userLines = Files.readAllLines(USERS_LIST);
            for (String userLine : userLines) {
                String[] userData = userLine.split(",");

                System.out.printf("-fn='%s' -ln='%s' -un='%s'\n", userData[0], userData[1], userData[2]);
            }
        }
    }

    private static void addTask(String[] args) throws Exception {
        String UserName = null;
        String taskTitle = null;
        String taskDescription = null;

        for (String arg : args) {
            if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-tt=")) {
                taskTitle = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-td=")) {
                taskDescription = arg.substring(5, arg.length() - 1);
            }
        }

        String taskLine = String.format("%s,%s,%s\n", UserName, taskTitle, taskDescription);
        Files.writeString(TASKS_LIST, taskLine, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private static void showTasks(String[] args) throws Exception {
        String UserName = null;

        for (String arg : args) {
            if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            }
        }

        if (Files.exists(TASKS_LIST)) {
            List<String> taskLines = Files.readAllLines(TASKS_LIST);
            for (String taskLine : taskLines) {
                String[] taskData = taskLine.split(",");

                if (!taskData[0].equals(UserName)) {
                    continue;
                }

                System.out.printf("-un='%s' -tt='%s' -td='%s'\n", taskData[0], taskData[1], taskData[2]);
            }
        }
    }

    public static void main(String[] args) throws Exception {

        for (String arg : args) {
            if (arg.equals("-createUser")) {
                createUser(args);
            } else if (arg.equals("-showAllUsers")) {
                showAllUsers(args);
            } else if (arg.equals("-addTask")) {
                addTask(args);
            } else if (arg.equals("-showTasks")) {
                showTasks(args);
            }
        }
    }
}
