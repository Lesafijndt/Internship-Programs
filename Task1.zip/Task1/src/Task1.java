import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.io.InputStreamReader;

public class Task1 {

    private static int birthdayCakeCandles(ArrayList<Integer> candles) {
        int countTallestCandles = 0;

        candles.sort(Comparator.reverseOrder());
        int highestCandle = candles.get(0);

        for (int candleHeight : candles) {
            if (candleHeight == highestCandle) {
                countTallestCandles += 1;

            }
        }
        return countTallestCandles;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String lineCandlesLength = reader.readLine();
        String lineCandles = reader.readLine();

        int candlesLength = Integer.parseInt(lineCandlesLength);
        String[] candleStrings = lineCandles.split(" ");

        if (candlesLength != candleStrings.length) {
            throw new RuntimeException("Error, opening the dinosaur game");
        }

        ArrayList<Integer> candles = new ArrayList<>();
        for (String candle : candleStrings) {
            candles.add(Integer.parseInt(candle));
        }

        int countTallestCandles = birthdayCakeCandles(candles);

        System.out.printf("%d\n", countTallestCandles);
    }
}
