CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  userId TEXT REFERENCES users(id),
  title TEXT,
  description TEXT
);
