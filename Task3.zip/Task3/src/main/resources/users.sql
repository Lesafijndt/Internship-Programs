CREATE TABLE users (
  id TEXT PRIMARY KEY,
  userName TEXT UNIQUE,
  firstName TEXT,
  lastName TEXT
);
