package tasks;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

public class App {
    private static String getResource(String name) throws Exception {
        try (InputStream istream = App.class.getResourceAsStream(name)) {
            return new String(istream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static Connection getConnection() throws SQLException, Exception {
        Connection connection = DriverManager.getConnection("jdbc:sqlite:tasks.db");

        try (Statement statement = connection.createStatement()) {
            try (ResultSet resultset = statement.executeQuery("PRAGMA user_version")) {
                resultset.next();

                int version = resultset.getInt(1);
                if (version < 1) {
                    statement.executeUpdate(getResource("/users.sql"));
                    statement.executeUpdate(getResource("/tasks.sql"));
                    statement.executeUpdate("user_version = 1");
                }
            }
        }

        return connection;
    }

    private static void createUser(String[] args) throws SQLException, Exception {
        String firstName = null;
        String lastName = null;
        String UserName = null;

        for (String arg : args) {
            if (arg.startsWith("-fn=")) {
                firstName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-ln=")) {
                lastName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            }
        }

        try (Connection connection = getConnection()) {
            String sql = "INSERT INTO users (id, UserName, firstName, lastName) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, UUID.randomUUID().toString());
                statement.setString(2, UserName);
                statement.setString(3, firstName);
                statement.setString(4, lastName);
                statement.executeUpdate();
            }
        }
    }

    private static void showAllUsers(String[] args) throws SQLException, Exception {
        try (Connection connection = getConnection()) {
            String sql = "SELECT * FROM users";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                try (ResultSet resultset = statement.executeQuery()) {
                    while (resultset.next()) {
                        String firstName = resultset.getString("firstName");
                        String lastName = resultset.getString("lastName");
                        String UserName = resultset.getString("UserName");

                        System.out.printf("-fn='%s' -ln='%s' -un='%s'\n", firstName, lastName, UserName);
                    }
                }
            }
        }
    }

    private static void addTask(String[] args) throws SQLException, Exception {
        String UserName = null;
        String taskTitle = null;
        String taskDescription = null;

        for (String arg : args) {
            if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-tt=")) {
                taskTitle = arg.substring(5, arg.length() - 1);
            } else if (arg.startsWith("-td=")) {
                taskDescription = arg.substring(5, arg.length() - 1);
            }
        }

        try (Connection connection = getConnection()) {
            String sql = "INSERT INTO tasks (id, userId, title, description) VALUES (?, (SELECT id FROM users WHERE UserName = ?), ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, UUID.randomUUID().toString());
                statement.setString(2, UserName);
                statement.setString(3, taskTitle);
                statement.setString(4, taskDescription);
                statement.executeUpdate();
            }
        }
    }

    private static void showTasks(String[] args) throws SQLException, Exception {
        String UserName = null;

        for (String arg : args) {
            if (arg.startsWith("-un=")) {
                UserName = arg.substring(5, arg.length() - 1);
            }
        }

        try (Connection connection = getConnection()) {
            String sql = "SELECT * FROM tasks WHERE userId = (SELECT id FROM users WHERE UserName = ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, UserName);

                try (ResultSet resultset = statement.executeQuery()) {
                    while (resultset.next()) {
                        String taskTitle = resultset.getString("title");
                        String taskDescription = resultset.getString("description");

                        System.out.printf("-un='%s' -tt='%s' -td='%s'\n", UserName, taskTitle, taskDescription);
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {

        for (String arg : args) {
            if (arg.equals("-createUser")) {
                createUser(args);
            } else if (arg.equals("-showAllUsers")) {
                showAllUsers(args);
            } else if (arg.equals("-addTask")) {
                addTask(args);
            } else if (arg.equals("-showTasks")) {
                showTasks(args);
            }
        }
    }
}
